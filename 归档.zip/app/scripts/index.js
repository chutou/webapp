console.log('\'Allo \'Allo!'); // eslint-disable-line no-console
$('#header').click(function(event) {
	/* Act on the event */
	
});